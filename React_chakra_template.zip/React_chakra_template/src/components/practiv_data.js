import face1 from "../assets/images/images(1).jpeg"
import face2 from "../assets/images/images(2).jpeg"
import face3 from "../assets/images/images(3).jpeg"

const facedata = [
    {
        img:face1,
        text:"Face 1"
    },
    {
        img:face2,
        text:"Face 2"
    },
    {
        img:face3,
        text:"Face 3"
    },
]

export {facedata};