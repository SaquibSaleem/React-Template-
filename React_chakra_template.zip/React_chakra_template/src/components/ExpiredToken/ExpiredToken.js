import { Box } from '@chakra-ui/react';
import jwtDecode from 'jwt-decode';
import React from 'react';
import { useState } from 'react';


const ExpiredToken = (token) => {
  // if(!token){
  //   return false;
  // }
//   const tokenData = jwtDecode(token);
//  console.log("tokenData",tokenData);
//  return false;
return false;
};




export { ExpiredToken };
