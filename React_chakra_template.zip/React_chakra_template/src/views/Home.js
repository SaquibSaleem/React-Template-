import {Stack, Box,Container,Text } from '@chakra-ui/react'
import React from 'react'
import {facedata} from "../components/practiv_data"
import { Row } from 'antd'

function Home() {   
    const Practicdummy = ({dum}) =>{
        return(
            <Stack direction={"row"} justifyContent={"space-between"}>
                <Box display={"flex"} alignItems={"center"}  w={"100%"} justifyContent={"space-between"}>
                    <Text>{dum.text}</Text>
                    <img src={dum.img} alt='dummy'/>
                </Box>
            </Stack>
        )
    }


  return (
    <>
        <Container maxW={"container.xl"}>
            {facedata.map((dum,index) => {
                return(
                    <Practicdummy key={index} dum={dum}/>
                )
            })}
        </Container>
    </>
  )
}

export default Home