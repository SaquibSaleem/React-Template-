import { Stack } from '@chakra-ui/react'

export default function Index() {
  return (
    <Stack>Header Component</Stack>
  )
}
